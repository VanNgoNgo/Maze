// 
// Decompiled by Procyon v0.5.36
// 

package TetHw;

import java.util.List;
import java.util.Collections;
import java.util.Comparator;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Race
{
    Runner[] array;
    
    public Race() {
        this.array = new Runner[2000];
    }
    
    public static void main(final String[] args) {
        final Race race = new Race();
        final Scanner sc = new Scanner(System.in);
        final Random rand = new Random();
        int count = 0;
        final ArrayList<Integer> arrayList = new ArrayList<Integer>();
        while (sc.hasNext()) {
            System.out.println("Enter runner's name: ");
            (race.array[count] = new Runner(sc.next())).setRandomNum(rand.nextInt(10000));
            arrayList.add(race.array[count].getRandomNum());
            ++count;
        }
        System.out.println("Want to enter another runners'details?");
        if (sc.next() == "Y") {
            race.array[count].addDetails();
        }
        else {
            System.exit(0);
        }
        Collections.sort(arrayList, new Comparator<Integer>() {
            @Override
            public int compare(final Integer o1, final Integer o2) {
                return o2 - o1;
            }
        });
    }
}
