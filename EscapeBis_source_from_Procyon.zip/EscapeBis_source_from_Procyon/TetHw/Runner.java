// 
// Decompiled by Procyon v0.5.36
// 

package TetHw;

public class Runner
{
    private String name;
    private int randomNum;
    private int finishedTime;
    
    public Runner(final String name) {
        this.name = name;
    }
    
    public int getRandomNum() {
        return this.randomNum;
    }
    
    public void setRandomNum(final int randomNum) {
        this.randomNum = randomNum;
    }
    
    public int getFinishedTime() {
        return this.finishedTime;
    }
    
    public void setFinishedTime(final int finishedTime) {
        this.finishedTime = finishedTime;
    }
    
    public void addDetails() {
    }
}
