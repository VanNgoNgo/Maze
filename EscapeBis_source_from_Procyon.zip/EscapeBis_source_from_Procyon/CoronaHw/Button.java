// 
// Decompiled by Procyon v0.5.36
// 

package CoronaHw;

import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.Rectangle;
import java.awt.geom.Area;
import java.awt.Component;

public class Button extends Component
{
    private int x;
    private int y;
    private Area rectangle;
    private String text;
    
    public Button(final int x, final int y) {
        this.x = x;
        this.y = y;
        this.rectangle = new Area(new Rectangle(x, y, 50, 50));
    }
    
    public Area getRectangle() {
        return this.rectangle;
    }
    
    public void setText(final String text) {
        this.text = text;
    }
    
    public void draw(final Graphics2D g2d) {
        g2d.draw(this.rectangle);
        g2d.drawString(this.text, this.x + 21, this.y + 28);
    }
}
