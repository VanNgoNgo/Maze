// 
// Decompiled by Procyon v0.5.36
// 

package CoronaHw;

import java.awt.event.KeyEvent;
import java.awt.geom.Point2D;
import java.awt.event.MouseEvent;
import java.awt.Dimension;
import java.awt.Component;
import java.awt.Graphics;
import java.util.Iterator;
import java.awt.Shape;
import java.awt.Rectangle;
import java.awt.Color;
import java.awt.Stroke;
import java.awt.BasicStroke;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.KeyboardFocusManager;
import EscapeBISNoMVC.Direction;
import javax.swing.JFrame;
import java.util.HashMap;
import java.awt.geom.Area;
import EscapeBISNoMVC.Block;
import java.util.Random;
import java.awt.geom.Line2D;
import java.util.ArrayList;
import java.awt.KeyEventPostProcessor;
import java.awt.event.MouseListener;
import java.awt.event.KeyListener;
import javax.swing.JPanel;

public class Maze extends JPanel implements KeyListener, MouseListener, KeyEventPostProcessor
{
    ArrayList<Line2D.Double> obstacles;
    ArrayList<String> move;
    int currentRow;
    int currentColumn;
    int currentX;
    int currentY;
    Random rand;
    private Block[][] table;
    private int x;
    private int y;
    private String player;
    Button NorthButton;
    Button SouthButton;
    Button EastButton;
    Button WestButton;
    Button quitButton;
    Area info;
    private String message;
    private boolean finished;
    static HashMap<String, Integer> map;
    JFrame frame;
    
    static {
        Maze.map = new HashMap<String, Integer>();
    }
    
    public Block[][] getTable() {
        return this.table;
    }
    
    public void setTable(final Block[][] table) {
        this.table = table;
    }
    
    public boolean isFinished() {
        return this.finished;
    }
    
    public void setFinished(final boolean finished) {
        this.finished = finished;
    }
    
    public Maze(final int x, final int y) {
        this.obstacles = new ArrayList<Line2D.Double>();
        this.move = new ArrayList<String>();
        this.currentX = 0;
        this.currentY = 0;
        this.rand = new Random();
        this.table = new Block[][] { { new Block(0, Direction.EAST), new Block(1, Direction.NULL), new Block(2, Direction.WEST), new Block(3, Direction.NULL) }, { new Block(4, Direction.NULL), new Block(5, Direction.EAST), new Block(6, Direction.EAST), new Block(7, Direction.NULL) }, { new Block(8, Direction.EAST), new Block(9, Direction.WEST), new Block(10, Direction.EAST), new Block(11, Direction.NULL) }, { new Block(12, Direction.NULL), new Block(13, Direction.NORTH), new Block(14, Direction.EAST), new Block(15, Direction.NULL) } };
        this.finished = false;
        this.frame = new JFrame();
        this.x = x + 100;
        this.y = y + 200;
        this.setFocusable(false);
        this.setFocusable(true);
        this.addKeyListener(this);
        this.addMouseListener(this);
        this.setVisible(true);
        KeyboardFocusManager.getCurrentKeyboardFocusManager().addKeyEventPostProcessor(this);
    }
    
    public void drawString(final Graphics2D g2d, final String message, final int x, final int y) {
        g2d.setFont(new Font(g2d.getFont().getName(), 0, 15));
        if (message.length() * 15 >= this.info.getBounds().width) {
            final String[] arr = message.split(" ");
            String temp = "";
            String print = "";
            final int startX = x;
            final int startY = y;
            int currentI = 0;
            for (int i = 0; i < arr.length; ++i) {
                print = temp;
                temp = String.valueOf(temp) + " " + arr[i];
                if (temp.length() * 15 >= this.info.getBounds().width) {
                    g2d.drawString(print, startX, startY);
                }
                currentI = i;
            }
            if (currentI < arr.length - 1) {
                String nextMessage = "";
                for (int j = currentI; j < arr.length; ++j) {
                    nextMessage = String.valueOf(nextMessage) + " " + arr[j];
                }
                this.drawString(g2d, message, startX, startY + 40);
            }
        }
        else {
            g2d.drawString(message, x + 20, y);
        }
    }
    
    public void drawMaze(final Graphics2D g2d) {
        final BasicStroke stroke = new BasicStroke(1.0f, 1, 0);
        g2d.setStroke(stroke);
        g2d.setColor(Color.WHITE);
        g2d.fill(new Rectangle(0, 0, 1600, 900));
        g2d.setColor(Color.GRAY);
        g2d.draw(this.info = new Area(new Rectangle(this.x, this.y + 300, 550, 200)));
        if (this.move.size() == 0) {
            this.setMessage("You are at room X, click on directions to move ? ");
        }
        else if (this.table[this.currentRow][this.currentColumn].getRoomNumber() == 15) {
            String string = "";
            for (final String e : this.move) {
                string = String.valueOf(string) + e + " ";
            }
            this.setMessage("Mission is completed. Previous move: " + string);
            g2d.setFont(new Font(g2d.getFont().getName(), 0, 15));
            g2d.drawString("Quit button is disabled. ", this.x + 20, this.y + 350);
        }
        g2d.setFont(new Font(g2d.getFont().getName(), 0, 15));
        this.drawString(g2d, this.message, this.x + 20, this.y + 320);
        int startX = this.x + 100;
        int startY = this.y;
        for (int i = 0; i < this.table.length; ++i) {
            for (int j = 0; j < this.table[0].length; ++j) {
                if (this.table[i][j].checkBlocked()) {
                    this.table[i][j].drawObstacle(g2d, startX, startY);
                }
                g2d.drawString((this.table[i][j].getRoomNumber() == this.table[this.currentRow][this.currentColumn].getRoomNumber()) ? "X" : String.valueOf(this.table[i][j].getRoomNumber()), startX, startY);
                startX += 80;
            }
            startX = this.x + 100;
            startY += 80;
        }
        startX = this.x + 100;
        startY = this.y;
        g2d.drawRect(startX - 40, startY - 40, 320, 320);
        (this.NorthButton = new Button(this.x, this.y)).setText("N");
        this.NorthButton.draw(g2d);
        (this.SouthButton = new Button(this.x, this.y + 60)).setText("S");
        this.SouthButton.draw(g2d);
        (this.EastButton = new Button(this.x, this.y + 120)).setText("E");
        this.EastButton.draw(g2d);
        (this.WestButton = new Button(this.x, this.y + 180)).setText("W");
        this.WestButton.draw(g2d);
        (this.quitButton = new Button(500, 300)).setText("Q");
        this.quitButton.draw(g2d);
    }
    
    public void move(final String direction) {
        switch (direction) {
            case "E": {
                if (this.currentColumn != 3 && !this.checkBlocked("E")) {
                    ++this.currentColumn;
                    this.repaint();
                    this.move.add("E");
                    break;
                }
                System.out.println("Cannot go in this direction. Please choose again");
                break;
            }
            case "N": {
                if (this.currentRow != 0 && !this.checkBlocked("N")) {
                    --this.currentRow;
                    this.repaint();
                    this.move.add("N");
                    break;
                }
                System.out.println("Cannot go in this direction. Please choose again");
                break;
            }
            case "S": {
                if (this.currentRow != 3 && !this.checkBlocked("S")) {
                    ++this.currentRow;
                    this.repaint();
                    this.move.add("S");
                    break;
                }
                System.out.println("Cannot go in this direction. Please choose again");
                break;
            }
            case "W": {
                if (this.currentColumn != 0 && !this.checkBlocked("W")) {
                    --this.currentColumn;
                    this.repaint();
                    this.move.add("W");
                    break;
                }
                System.out.println("Cannot go in this direction. Please choose again");
                break;
            }
            default:
                break;
        }
        if (this.table[this.currentRow][this.currentColumn].getRoomNumber() == 15) {
            System.out.println("Mission is completed");
            this.setMessage("Mission is completed");
            System.out.println("Previous move: ");
            for (final String e : this.move) {
                System.out.print(String.valueOf(e) + " ");
            }
            this.setFinished(true);
        }
    }
    
    public boolean checkBlocked(final String direction) {
        switch (direction) {
            case "E": {
                return this.table[this.currentRow][this.currentColumn].getBlocked().contains(Direction.EAST);
            }
            case "N": {
                return this.table[this.currentRow][this.currentColumn].getBlocked().contains(Direction.NORTH);
            }
            case "S": {
                return this.table[this.currentRow][this.currentColumn].getBlocked().contains(Direction.SOUTH);
            }
            case "W": {
                return this.table[this.currentRow][this.currentColumn].getBlocked().contains(Direction.WEST);
            }
            default:
                break;
        }
        return false;
    }
    
    @Override
    protected void paintComponent(final Graphics g) {
        super.paintComponents(g);
        final Graphics2D g2d = (Graphics2D)g;
        this.drawMaze(g2d);
        this.repaint();
    }
    
    public void createPlayer() {
        this.frame.add(this);
        this.frame.addKeyListener(this);
        this.frame.setFocusable(true);
        this.frame.setPreferredSize(new Dimension(800, 800));
        this.frame.setDefaultCloseOperation(3);
        this.frame.pack();
        this.frame.setBackground(Color.WHITE);
        this.frame.setLocationRelativeTo(this);
        this.frame.setVisible(true);
    }
    
    public static void main(final String[] args) {
        final Maze mazeOnePerson = new Maze(0, 0);
        mazeOnePerson.createPlayer();
    }
    
    @Override
    public void mouseClicked(final MouseEvent e) {
        if (!this.isFinished()) {
            if (this.NorthButton.getRectangle().contains(e.getPoint())) {
                this.move("N");
                this.repaint();
            }
            else if (this.SouthButton.getRectangle().contains(e.getPoint())) {
                this.move("S");
                this.repaint();
            }
            else if (this.WestButton.getRectangle().contains(e.getPoint())) {
                this.move("W");
                this.repaint();
            }
            else if (this.EastButton.getRectangle().contains(e.getPoint())) {
                this.move("E");
                this.repaint();
            }
            else if (this.quitButton.getRectangle().contains(e.getPoint())) {
                this.frame.dispose();
                this.frame.setVisible(false);
            }
        }
    }
    
    @Override
    public void mousePressed(final MouseEvent e) {
    }
    
    @Override
    public void mouseReleased(final MouseEvent e) {
    }
    
    @Override
    public void mouseEntered(final MouseEvent e) {
    }
    
    @Override
    public void mouseExited(final MouseEvent e) {
    }
    
    @Override
    public void keyTyped(final KeyEvent e) {
    }
    
    @Override
    public void keyPressed(final KeyEvent e) {
        switch (e.getKeyCode()) {
            case 224: {
                this.move("N");
                this.repaint();
                break;
            }
            case 225: {
                this.move("S");
                this.repaint();
                break;
            }
            case 226: {
                this.move("W");
                this.repaint();
                break;
            }
            case 227: {
                this.move("E");
                this.repaint();
                break;
            }
            case 10: {
                System.out.println("Pressed");
                break;
            }
        }
    }
    
    @Override
    public void keyReleased(final KeyEvent e) {
    }
    
    @Override
    public boolean postProcessKeyEvent(final KeyEvent ke) {
        if (ke.getID() == 401 && ke.getKeyCode() == 112) {
            Component c;
            for (c = ke.getComponent(); c.getParent() != null; c = c.getParent()) {}
            System.out.println("Help for " + c.getName() + "." + ke.getComponent().getName());
            return true;
        }
        return false;
    }
    
    public void setMessage(final String message) {
        this.message = message;
    }
    
    public String getPlayer() {
        return this.player;
    }
    
    public void setPlayer(final String player) {
        this.player = player;
    }
}
