// 
// Decompiled by Procyon v0.5.36
// 

package CoronaHw;

public enum Direction
{
    NORTH("NORTH", 0), 
    SOUTH("SOUTH", 1), 
    WEST("WEST", 2), 
    EAST("EAST", 3);
    
    private Direction(final String name, final int ordinal) {
    }
}
