// 
// Decompiled by Procyon v0.5.36
// 

package EscapeBISNoMVC;

import java.util.Scanner;
import java.util.Iterator;
import java.util.ArrayList;

public class Maze4x4
{
    private int currentRow;
    private int currentColumn;
    private ArrayList<String> move;
    private Block[][] arr;
    
    public Maze4x4() {
        this.currentRow = 0;
        this.currentColumn = 0;
        this.move = new ArrayList<String>();
        this.arr = new Block[][] { { new Block(0, Direction.EAST), new Block(1, Direction.SOUTH), new Block(2, Direction.WEST), new Block(3, Direction.NULL) }, { new Block(4, Direction.NULL), new Block(5, Direction.EAST), new Block(6, Direction.EAST), new Block(7, Direction.NULL) }, { new Block(8, Direction.EAST), new Block(9, Direction.WEST), new Block(10, Direction.EAST), new Block(11, Direction.NULL) }, { new Block(12, Direction.NULL), new Block(13, Direction.NULL), new Block(14, Direction.EAST), new Block(15, Direction.NULL) } };
    }
    
    public void print() {
        for (int i = 0; i < this.arr.length; ++i) {
            for (int j = 0; j < this.arr[0].length; ++j) {
                System.out.printf(" %8s", (this.arr[i][j].getRoomNumber() == this.arr[this.currentRow][this.currentColumn].getRoomNumber()) ? this.arr[i][j].printCurrentPosition() : this.arr[i][j].print());
            }
            System.out.println();
        }
    }
    
    public void move(final String direction) {
        switch (direction) {
            case "E": {
                if (this.currentColumn != 3 && !this.checkBlocked("E")) {
                    ++this.currentColumn;
                    this.print();
                    this.move.add("E");
                    break;
                }
                System.out.println("Cannot go in this direction. Please choose again");
                break;
            }
            case "N": {
                if (this.currentRow != 0 && !this.checkBlocked("N")) {
                    --this.currentRow;
                    this.print();
                    this.move.add("N");
                    break;
                }
                System.out.println("Cannot go in this direction. Please choose again");
                break;
            }
            case "S": {
                if (this.currentRow != 3 && !this.checkBlocked("S")) {
                    ++this.currentRow;
                    this.print();
                    this.move.add("S");
                    break;
                }
                System.out.println("Cannot go in this direction. Please choose again");
                break;
            }
            case "W": {
                if (this.currentColumn != 0 && !this.checkBlocked("W")) {
                    --this.currentColumn;
                    this.print();
                    this.move.add("W");
                    break;
                }
                System.out.println("Cannot go in this direction. Please choose again");
                break;
            }
            default:
                break;
        }
        if (this.arr[this.currentRow][this.currentColumn].getRoomNumber() == 15) {
            System.out.println("Mission is completed");
            System.out.println("Previous move: ");
            for (final String e : this.move) {
                System.out.print(String.valueOf(e) + " ");
            }
        }
    }
    
    public boolean checkBlocked(final String direction) {
        switch (direction) {
            case "E": {
                return this.arr[this.currentRow][this.currentColumn].getBlocked().contains(Direction.EAST);
            }
            case "N": {
                return this.arr[this.currentRow][this.currentColumn].getBlocked().contains(Direction.NORTH);
            }
            case "S": {
                return this.arr[this.currentRow][this.currentColumn].getBlocked().contains(Direction.SOUTH);
            }
            case "W": {
                return this.arr[this.currentRow][this.currentColumn].getBlocked().contains(Direction.WEST);
            }
            default:
                break;
        }
        return false;
    }
    
    public static void main(final String[] args) {
        final Scanner sc = new Scanner(System.in);
        final Maze4x4 maze = new Maze4x4();
        System.out.println("You are at room 0, enter N,S,E,W to move");
        maze.print();
        while (sc.hasNext() && maze.arr[maze.currentRow][maze.currentColumn].getRoomNumber() != 15) {
            maze.move(sc.next());
        }
    }
}
