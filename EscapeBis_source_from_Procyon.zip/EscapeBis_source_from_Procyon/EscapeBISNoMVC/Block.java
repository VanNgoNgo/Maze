// 
// Decompiled by Procyon v0.5.36
// 

package EscapeBISNoMVC;

import java.awt.Graphics2D;
import java.util.Iterator;
import java.util.ArrayList;

public class Block
{
    private ArrayList<Direction> blocked;
    private int roomNumber;
    private String printValue;
    private String printCurrentValue;
    Direction temp;
    
    public Block(final int roomNumber, final Direction blocked) {
        this.blocked = new ArrayList<Direction>(3);
        this.temp = null;
        this.blocked.add(blocked);
        this.roomNumber = roomNumber;
        if (Math.round((float)(roomNumber / 10)) == 0) {
            this.printValue = "0" + String.valueOf(roomNumber);
        }
        else {
            this.printValue = String.valueOf(roomNumber);
        }
    }
    
    public Block(final int roomNumber, final Direction... blocked) {
        this.blocked = new ArrayList<Direction>(3);
        this.temp = null;
        for (final Direction i : blocked) {
            if (this.temp != i) {
                this.blocked.add(i);
            }
            this.temp = i;
        }
        this.roomNumber = roomNumber;
        this.printValue = String.valueOf(roomNumber);
    }
    
    public String print() {
        for (final Direction direction : this.blocked) {
            switch (direction) {
                case EAST: {
                    return String.valueOf(this.printValue) + "|";
                }
                case SOUTH: {
                    final StringBuilder underlined = new StringBuilder();
                    char[] charArray;
                    for (int length = (charArray = this.printValue.toCharArray()).length, i = 0; i < length; ++i) {
                        final char c = charArray[i];
                        underlined.append(c).append('\u0332');
                    }
                    return new StringBuilder(String.valueOf(this.printValue)).toString();
                }
                case NORTH: {
                    return new StringBuilder(String.valueOf(this.printValue)).toString();
                }
                case WEST: {
                    return "|" + this.printValue;
                }
                default: {
                    continue;
                }
            }
        }
        return this.printValue;
    }
    
    public String printCurrentPosition() {
        this.printCurrentValue = "X";
        for (final Direction direction : this.blocked) {
            switch (direction) {
                case EAST: {
                    return this.printCurrentValue = String.valueOf(this.printCurrentValue) + "|";
                }
                case SOUTH: {
                    return this.printCurrentValue;
                }
                case NORTH: {
                    return this.printCurrentValue;
                }
                case WEST: {
                    this.printCurrentValue = "|" + this.printValue;
                    System.out.print(this.printCurrentValue);
                    return this.printCurrentValue;
                }
                default: {
                    continue;
                }
            }
        }
        return String.valueOf(this.printCurrentValue) + " ";
    }
    
    public void drawObstacle(final Graphics2D g2d, final int x, final int y) {
        final int moveVert = 40;
        final int moveHoriz = 40;
        for (final Direction direction : this.getBlocked()) {
            if (direction == Direction.NORTH) {
                g2d.drawLine(x - moveHoriz, y - moveVert, x + moveHoriz, y - moveVert);
            }
            else if (direction == Direction.EAST) {
                g2d.drawLine(x + moveHoriz, y - moveVert, x + moveHoriz, y + moveVert);
            }
            else if (direction == Direction.WEST) {
                g2d.drawLine(x - moveHoriz, y - moveVert, x - moveHoriz, y + moveVert);
            }
            else {
                if (direction != Direction.SOUTH) {
                    continue;
                }
                g2d.drawLine(x - moveHoriz, y + moveVert, x + moveHoriz, y + moveVert);
            }
        }
    }
    
    public String getPrintCurrentValue() {
        return this.printCurrentValue;
    }
    
    public ArrayList<Direction> getBlocked() {
        return this.blocked;
    }
    
    public int getRoomNumber() {
        return this.roomNumber;
    }
    
    public String getPrintValue() {
        return this.printValue;
    }
    
    public boolean checkBlocked() {
        return this.blocked.size() != 0;
    }
}
