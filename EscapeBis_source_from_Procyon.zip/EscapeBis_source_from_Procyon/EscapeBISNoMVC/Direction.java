// 
// Decompiled by Procyon v0.5.36
// 

package EscapeBISNoMVC;

public enum Direction
{
    NORTH("NORTH", 0), 
    SOUTH("SOUTH", 1), 
    WEST("WEST", 2), 
    EAST("EAST", 3), 
    NULL("NULL", 4);
    
    private Direction(final String name, final int ordinal) {
    }
}
